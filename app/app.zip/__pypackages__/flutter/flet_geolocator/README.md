# Flet `Geolocator` control

`Geolocator` control to use in Flet apps.