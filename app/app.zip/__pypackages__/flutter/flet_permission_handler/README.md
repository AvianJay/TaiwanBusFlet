# Flet `PermissionHandler` control

`PermissionHandler` control to use in Flet apps.